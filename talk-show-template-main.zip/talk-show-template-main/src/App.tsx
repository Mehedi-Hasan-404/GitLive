import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import LiveTV from '@/pages/LiveTV';
import DirectStream from '@/pages/DirectStream';
import Favorites from '@/pages/Favorites';
import MyPlaylists from '@/pages/MyPlaylists';
import Player from '@/pages/Player';
import Admin from '@/pages/Admin';
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <Router>
        <div className="min-h-screen bg-background">
          <Routes>
            <Route path="/player" element={<Player />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/" element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="live" element={<LiveTV />} />
              <Route path="direct" element={<DirectStream />} />
              <Route path="favorites" element={<Favorites />} />
              <Route path="playlists" element={<MyPlaylists />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>
      </Router>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
