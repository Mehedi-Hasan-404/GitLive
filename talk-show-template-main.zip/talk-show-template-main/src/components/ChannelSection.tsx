import { useState } from "react";
import { Filter, Grid3X3, List, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import ChannelCard from "./ChannelCard";

interface ChannelSectionProps {
  title: string;
  channels: Array<{
    id: string;
    name: string;
    category: string;
    viewers: string;
    isLive?: boolean;
    isPremium?: boolean;
    image: string;
    description?: string;
  }>;
  showViewAll?: boolean;
}

const ChannelSection = ({ title, channels, showViewAll = true }: ChannelSectionProps) => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  return (
    <section className="space-y-6">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-bold text-foreground">{title}</h2>
          <Badge variant="secondary" className="text-xs">
            {channels.filter(c => c.isLive).length} Live
          </Badge>
        </div>

        <div className="flex items-center gap-2">
          {/* View Mode Toggle */}
          <div className="hidden sm:flex items-center bg-muted rounded-lg p-1">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('grid')}
              className="h-8 w-8 p-0"
            >
              <Grid3X3 className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('list')}
              className="h-8 w-8 p-0"
            >
              <List className="h-4 w-4" />
            </Button>
          </div>

          {/* Filter */}
          <Button variant="outline" size="sm" className="hidden md:flex">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>

          {/* View All */}
          {showViewAll && (
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
              View All
              <ChevronRight className="ml-1 h-4 w-4" />
            </Button>
          )}
        </div>
      </div>

      {/* Channels Grid */}
      <div className={`
        ${viewMode === 'grid' 
          ? 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4' 
          : 'grid grid-cols-1 sm:grid-cols-2 gap-4'
        }
      `}>
        {channels.map((channel) => (
          <ChannelCard
            key={channel.id}
            name={channel.name}
            category={channel.category}
            viewers={channel.viewers}
            isLive={channel.isLive}
            isPremium={channel.isPremium}
            image={channel.image}
            description={channel.description}
          />
        ))}
      </div>
    </section>
  );
};

export default ChannelSection;