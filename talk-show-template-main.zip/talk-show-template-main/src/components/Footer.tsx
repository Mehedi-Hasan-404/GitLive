import { Play, Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import streamhubLogo from "@/assets/streamhub-logo.png";

const Footer = () => {
  return (
    <footer className="bg-gradient-secondary border-t border-border">
      <div className="container max-w-screen-2xl py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <img 
                src={streamhubLogo} 
                alt="StreamHub" 
                className="h-8 w-8 rounded-full"
              />
              <h3 className="text-xl font-bold gradient-text">StreamHub</h3>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              The ultimate live streaming platform with premium content, 
              sports, movies, and entertainment available 24/7.
            </p>
            <div className="flex gap-2">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
                <Facebook className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
                <Twitter className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
                <Instagram className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
                <Youtube className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground">Quick Links</h4>
            <nav className="space-y-2">
              <Button variant="link" className="p-0 h-auto text-muted-foreground hover:text-primary justify-start">
                Live Channels
              </Button>
              <Button variant="link" className="p-0 h-auto text-muted-foreground hover:text-primary justify-start">
                Sports Events
              </Button>
              <Button variant="link" className="p-0 h-auto text-muted-foreground hover:text-primary justify-start">
                Movie Library
              </Button>
              <Button variant="link" className="p-0 h-auto text-muted-foreground hover:text-primary justify-start">
                Premium Plans
              </Button>
            </nav>
          </div>

          {/* Support */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground">Support</h4>
            <nav className="space-y-2">
              <Button variant="link" className="p-0 h-auto text-muted-foreground hover:text-primary justify-start">
                Help Center
              </Button>
              <Button variant="link" className="p-0 h-auto text-muted-foreground hover:text-primary justify-start">
                Privacy Policy
              </Button>
              <Button variant="link" className="p-0 h-auto text-muted-foreground hover:text-primary justify-start">
                Terms of Service
              </Button>
              <Button variant="link" className="p-0 h-auto text-muted-foreground hover:text-primary justify-start">
                Contact Us
              </Button>
            </nav>
            
            <div className="space-y-2 pt-2">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4" />
                <span>support@streamhub.com</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4" />
                <span>+1 (555) 123-4567</span>
              </div>
            </div>
          </div>

          {/* Newsletter */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground">Stay Updated</h4>
            <p className="text-sm text-muted-foreground">
              Subscribe to get notified about new channels and exclusive content.
            </p>
            <div className="space-y-2">
              <Input 
                placeholder="Your email address"
                className="bg-background border-border"
              />
              <Button variant="default" className="w-full">
                Subscribe
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border mt-12 pt-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">
              © 2024 StreamHub. All rights reserved.
            </p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-primary rounded-full live-pulse" />
                <span>24/7 Live Streaming</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;