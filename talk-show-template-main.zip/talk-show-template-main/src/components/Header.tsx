import { Search, Bell, User, Crown, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NavLink } from "react-router-dom";
import streamhubLogo from "@/assets/streamhub-logo.png";

const Header = () => {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 max-w-screen-2xl items-center justify-between">
        {/* Logo and Navigation */}
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-3">
            <img 
              src={streamhubLogo} 
              alt="StreamHub" 
              className="h-8 w-8 rounded-full"
            />
            <h1 className="text-xl font-bold gradient-text">StreamHub</h1>
          </div>
          
          <nav className="hidden md:flex items-center gap-6">
            <Button variant="ghost" asChild>
              <NavLink to="/live" className="flex items-center">
                <Play className="mr-2 h-4 w-4" />
                Live
              </NavLink>
            </Button>
            <Button variant="ghost" asChild>
              <NavLink to="/direct">Direct</NavLink>
            </Button>
            <Button variant="ghost" asChild>
              <NavLink to="/favorites">Favorites</NavLink>
            </Button>
            <Button variant="ghost" asChild>
              <NavLink to="/playlists">My Playlists</NavLink>
            </Button>
          </nav>
        </div>

        {/* Search and User Actions */}
        <div className="flex items-center gap-4">
          {/* Search */}
          <div className="relative hidden sm:block">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search channels, shows..."
              className="w-64 pl-10 bg-muted/50 border-border focus:border-primary"
            />
          </div>

          {/* User Actions */}
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
              <Bell className="h-5 w-5" />
            </Button>
            
            <Button variant="premium" size="sm" className="hidden sm:flex">
              <Crown className="mr-2 h-4 w-4" />
              Premium
            </Button>
            
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
              <User className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;