import { Play, Users, Zap, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const HeroSection = () => {
  return (
    <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden bg-gradient-hero">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-background/40 to-background/80" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-accent/10 rounded-full blur-3xl" />

      {/* Content */}
      <div className="relative z-10 container max-w-screen-xl text-center">
        <div className="space-y-8">
          {/* Badge */}
          <Badge variant="outline" className="px-4 py-2 text-sm bg-primary/10 border-primary/20 text-primary">
            <Zap className="mr-2 h-4 w-4" />
            Live Streaming Platform
          </Badge>

          {/* Main Heading */}
          <div className="space-y-4">
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold leading-tight">
              Stream Your <span className="gradient-text">Favorite</span>
              <br />
              Channels Live
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Discover thousands of live channels, sports events, movies, and entertainment. 
              Experience premium streaming with crystal clear quality and zero buffering.
            </p>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap justify-center gap-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              <span className="font-semibold text-foreground">2M+</span> Active Users
            </div>
            <div className="flex items-center gap-2">
              <Play className="h-4 w-4 text-primary" />
              <span className="font-semibold text-foreground">500+</span> Live Channels
            </div>
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4 text-primary" />
              <span className="font-semibold text-foreground">4.8</span> User Rating
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button variant="hero" size="xl" className="hero-glow">
              <Play className="mr-2 h-5 w-5" />
              Start Watching Free
            </Button>
            <Button variant="outline" size="xl" className="border-primary/20 hover:border-primary/50">
              Browse Channels
            </Button>
          </div>

          {/* Live Indicator */}
          <div className="flex items-center justify-center gap-2 text-sm">
            <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-live-indicator/10 border border-live-indicator/20">
              <div className="w-2 h-2 bg-live-indicator rounded-full live-pulse" />
              <span className="text-live-indicator font-semibold">Live Now</span>
            </div>
            <span className="text-muted-foreground">24/7 Streaming Available</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;