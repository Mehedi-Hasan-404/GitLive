import { useState } from 'react';
import { Search, Menu, Settings, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import streamhubLogo from "@/assets/streamhub-logo.png";

interface AppHeaderProps {
  onMenuClick: () => void;
  sidebarOpen: boolean;
}

const AppHeader = ({ onMenuClick, sidebarOpen }: AppHeaderProps) => {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container max-w-screen-2xl mx-auto flex h-16 items-center justify-between px-4">
          {/* Left Side */}
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={onMenuClick}
              className="md:hidden"
            >
              <Menu className="h-6 w-6" />
            </Button>
            
            <div className="flex items-center gap-3">
              <img 
                src={streamhubLogo} 
                alt="StreamHub" 
                className="h-8 w-8 rounded-full"
              />
              <h1 className="text-xl font-bold gradient-text hidden sm:block">StreamHub</h1>
            </div>
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSearchOpen(!searchOpen)}
            >
              <Search className="h-5 w-5" />
            </Button>
            
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Global Search Overlay */}
      {searchOpen && (
        <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container max-w-screen-2xl mx-auto px-4 pt-4">
            <div className="flex items-center gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search channels, categories..."
                  className="w-full pl-10 h-12 text-base"
                  autoFocus
                />
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSearchOpen(false)}
              >
                <X className="h-6 w-6" />
              </Button>
            </div>
            
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Start typing to search across all channels and categories...
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AppHeader;