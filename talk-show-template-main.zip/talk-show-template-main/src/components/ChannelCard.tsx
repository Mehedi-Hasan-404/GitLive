import { Play, Users, Dot, Heart } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

interface ChannelCardProps {
  name: string;
  category: string;
  viewers: string;
  isLive?: boolean;
  isPremium?: boolean;
  image: string;
  description?: string;
}

const ChannelCard = ({ 
  name, 
  category, 
  viewers, 
  isLive = true, 
  isPremium = false, 
  image, 
  description 
}: ChannelCardProps) => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handlePlay = () => {
    // Mock stream URL - in real app this would come from the channel data
    const mockStreamUrl = `https://example.com/streams/${name.toLowerCase().replace(/\s+/g, '-')}.m3u8`;
    
    navigate(`/player?url=${encodeURIComponent(mockStreamUrl)}&name=${encodeURIComponent(name)}&type=HLS`);
    
    toast({
      title: "Starting Stream",
      description: `Now playing ${name}`
    });
  };

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    // TODO: Implement favorites functionality with localStorage
    toast({
      title: "Added to Favorites",
      description: `${name} has been added to your favorites`
    });
  };
  return (
    <div className="channel-card group p-4 space-y-4 relative overflow-hidden cursor-pointer" onClick={handlePlay}>
      {/* Channel Image */}
      <div className="relative">
        <div className="aspect-square rounded-xl overflow-hidden bg-muted">
          <img 
            src={image} 
            alt={name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          
          {/* Overlay on hover */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Play button overlay */}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center shadow-glow">
              <Play className="w-5 h-5 text-primary-foreground ml-0.5" fill="currentColor" />
            </div>
          </div>

          {/* Favorite button */}
          <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleFavorite}
              className="w-8 h-8 bg-black/50 hover:bg-black/70 text-white"
            >
              <Heart className="w-4 h-4" />
            </Button>
          </div>

          {/* Status badges */}
          <div className="absolute top-3 left-3 flex gap-2">
            {isLive && (
              <Badge className="bg-live-indicator hover:bg-live-indicator text-white border-0 text-xs font-semibold">
                <Dot className="w-3 h-3 mr-1 animate-pulse" />
                LIVE
              </Badge>
            )}
            {isPremium && (
              <Badge className="bg-premium hover:bg-premium text-black border-0 text-xs font-semibold">
                PRO
              </Badge>
            )}
          </div>

          {/* Viewer count */}
          {isLive && (
            <div className="absolute bottom-3 right-3 flex items-center gap-1 px-2 py-1 bg-black/70 rounded-md text-white text-xs">
              <Users className="w-3 h-3" />
              <span className="font-medium">{viewers}</span>
            </div>
          )}
        </div>
      </div>

      {/* Channel Info */}
      <div className="space-y-2">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors truncate">
            {name}
          </h3>
        </div>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span className="px-2 py-1 bg-muted rounded-md text-xs font-medium">
            {category}
          </span>
          {description && (
            <span className="truncate">{description}</span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChannelCard;