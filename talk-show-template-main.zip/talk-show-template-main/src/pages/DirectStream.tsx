import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Play, Settings, ChevronDown, ChevronUp, Clock, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

const DirectStream = () => {
  const navigate = useNavigate();
  const [streamUrl, setStreamUrl] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [referer, setReferer] = useState('');
  const [origin, setOrigin] = useState('');
  const [cookies, setCookies] = useState('');
  const [userAgent, setUserAgent] = useState('');
  const [customUserAgent, setCustomUserAgent] = useState('');
  const [drmType, setDrmType] = useState('');
  const [licenseUrl, setLicenseUrl] = useState('');
  const [licenseHeaders, setLicenseHeaders] = useState('');
  const [clearKeyPairs, setClearKeyPairs] = useState('');
  
  const { toast } = useToast();

  // Mock recent streams
  const recentStreams = [
    {
      id: 1,
      url: 'https://example.com/stream1.m3u8',
      name: 'Sports Channel HD',
      timestamp: '2 hours ago',
      type: 'HLS'
    },
    {
      id: 2,
      url: 'https://example.com/stream2.mpd',
      name: 'Movie Channel 4K',
      timestamp: '1 day ago',
      type: 'DASH'
    }
  ];

  const userAgentPresets = [
    { value: 'chrome', label: 'Chrome (Windows)' },
    { value: 'firefox', label: 'Firefox (Windows)' },
    { value: 'safari', label: 'Safari (macOS)' },
    { value: 'android', label: 'Android Browser' },
    { value: 'iphone', label: 'iPhone Safari' },
    { value: 'smarttv', label: 'Smart TV' },
    { value: 'custom', label: 'Custom' }
  ];

  const drmTypes = [
    { value: 'widevine', label: 'Widevine' },
    { value: 'clearkey', label: 'ClearKey' },
    { value: 'playready', label: 'PlayReady' },
    { value: 'fairplay', label: 'FairPlay (Safari)' }
  ];

  const detectStreamType = (url: string) => {
    if (url.includes('.m3u8') || url.includes('.m3u')) return 'HLS';
    if (url.includes('.mpd')) return 'DASH';
    if (url.includes('.mp4')) return 'MP4';
    return 'Unknown';
  };

  const handlePlay = () => {
    if (!streamUrl.trim()) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please enter a stream URL"
      });
      return;
    }

    const streamType = detectStreamType(streamUrl);
    
    // Navigate to player with stream URL and configuration
    navigate(`/player?url=${encodeURIComponent(streamUrl)}&name=${encodeURIComponent('Direct Stream')}&type=${streamType}`);
  };

  const handleRecentStreamPlay = (stream: any) => {
    navigate(`/player?url=${encodeURIComponent(stream.url)}&name=${encodeURIComponent(stream.name)}&type=${stream.type}`);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Direct Stream</h1>
        <p className="text-muted-foreground">
          Play any stream URL directly with advanced configuration options
        </p>
      </div>

      {/* Main Stream Input */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ExternalLink className="w-5 h-5" />
            Stream URL
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <div className="flex-1">
              <Input
                placeholder="https://example.com/stream.m3u8 or .m3u or .mpd or .mp4"
                value={streamUrl}
                onChange={(e) => setStreamUrl(e.target.value)}
                className="text-sm"
              />
              {streamUrl && (
                <div className="mt-2 flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">
                    {detectStreamType(streamUrl)}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    Stream format auto-detected
                  </span>
                </div>
              )}
            </div>
            <Button onClick={handlePlay} className="px-8">
              <Play className="w-4 h-4 mr-2" />
              Play
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Advanced Options */}
      <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
        <CollapsibleTrigger asChild>
          <Button variant="outline" className="w-full">
            <Settings className="w-4 h-4 mr-2" />
            Advanced Options
            {showAdvanced ? (
              <ChevronUp className="w-4 h-4 ml-auto" />
            ) : (
              <ChevronDown className="w-4 h-4 ml-auto" />
            )}
          </Button>
        </CollapsibleTrigger>
        
        <CollapsibleContent className="space-y-4 mt-4">
          {/* Headers & Authentication */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Headers & Authentication</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Referer</label>
                  <Input
                    placeholder="https://example.com"
                    value={referer}
                    onChange={(e) => setReferer(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Origin</label>
                  <Input
                    placeholder="https://example.com"
                    value={origin}
                    onChange={(e) => setOrigin(e.target.value)}
                  />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Cookies</label>
                <Textarea
                  placeholder="session=abc123; auth=xyz789"
                  value={cookies}
                  onChange={(e) => setCookies(e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* User Agent */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">User Agent</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select value={userAgent} onValueChange={setUserAgent}>
                <SelectTrigger>
                  <SelectValue placeholder="Select user agent preset" />
                </SelectTrigger>
                <SelectContent>
                  {userAgentPresets.map((preset) => (
                    <SelectItem key={preset.value} value={preset.value}>
                      {preset.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              {userAgent === 'custom' && (
                <Textarea
                  placeholder="Enter custom user agent string..."
                  value={customUserAgent}
                  onChange={(e) => setCustomUserAgent(e.target.value)}
                  rows={2}
                />
              )}
            </CardContent>
          </Card>

          {/* DRM Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">DRM Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select value={drmType} onValueChange={setDrmType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select DRM type (optional)" />
                </SelectTrigger>
                <SelectContent>
                  {drmTypes.map((drm) => (
                    <SelectItem key={drm.value} value={drm.value}>
                      {drm.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {drmType && drmType !== 'clearkey' && (
                <>
                  <div>
                    <label className="text-sm font-medium mb-2 block">License Server URL</label>
                    <Input
                      placeholder="https://example.com/license"
                      value={licenseUrl}
                      onChange={(e) => setLicenseUrl(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">License Headers (JSON)</label>
                    <Textarea
                      placeholder='{"Authorization": "Bearer token", "X-Custom": "value"}'
                      value={licenseHeaders}
                      onChange={(e) => setLicenseHeaders(e.target.value)}
                      rows={3}
                    />
                  </div>
                </>
              )}

              {drmType === 'clearkey' && (
                <div>
                  <label className="text-sm font-medium mb-2 block">ClearKey Pairs (KeyID:Key per line)</label>
                  <Textarea
                    placeholder="keyid1:key1&#10;keyid2:key2"
                    value={clearKeyPairs}
                    onChange={(e) => setClearKeyPairs(e.target.value)}
                    rows={3}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </CollapsibleContent>
      </Collapsible>

      {/* Recent Streams */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Recent Streams
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recentStreams.length > 0 ? (
            <div className="space-y-3">
              {recentStreams.map((stream) => (
                <div key={stream.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground truncate">{stream.name}</p>
                    <p className="text-sm text-muted-foreground truncate">{stream.url}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-xs">{stream.type}</Badge>
                      <span className="text-xs text-muted-foreground">{stream.timestamp}</span>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => handleRecentStreamPlay(stream)}
                    className="ml-4"
                  >
                    <Play className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-6">
              No recent streams. Start playing streams to see your history here.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default DirectStream;