import { useState } from 'react';
import { Play, TrendingUp, Clock, Grid3X3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

// Mock data for categories
const categories = [
  { id: 1, name: 'Sports', icon: '⚽', color: 'bg-green-500', channels: 45 },
  { id: 2, name: 'Movies', icon: '🎬', color: 'bg-purple-500', channels: 128 },
  { id: 3, name: 'News', icon: '📺', color: 'bg-red-500', channels: 24 },
  { id: 4, name: 'Entertainment', icon: '🎭', color: 'bg-yellow-500', channels: 67 },
  { id: 5, name: 'Kids', icon: '🧸', color: 'bg-pink-500', channels: 32 },
  { id: 6, name: 'Music', icon: '🎵', color: 'bg-blue-500', channels: 18 },
];

// Mock popular channels
const popularChannels = [
  { id: 1, name: 'Premier Sports', thumbnail: '/api/placeholder/120/80', viewers: '24.5K', category: 'Sports' },
  { id: 2, name: 'Cinema Gold', thumbnail: '/api/placeholder/120/80', viewers: '18.2K', category: 'Movies' },
  { id: 3, name: 'Global News', thumbnail: '/api/placeholder/120/80', viewers: '31.7K', category: 'News' },
  { id: 4, name: 'Music Live', thumbnail: '/api/placeholder/120/80', viewers: '15.4K', category: 'Music' },
];

const Home = () => {
  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="relative rounded-2xl bg-gradient-to-r from-primary/20 via-primary/10 to-transparent p-8 md:p-12">
        <div className="max-w-2xl space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold gradient-text">
            Stream Unlimited
          </h1>
          <p className="text-lg text-muted-foreground">
            Watch thousands of live TV channels, movies, and shows from around the world. 
            Your entertainment hub awaits.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button size="lg" className="bg-gradient-primary hover:opacity-90">
              <Play className="mr-2 h-5 w-5" />
              Start Watching
            </Button>
            <Button variant="outline" size="lg">
              <Grid3X3 className="mr-2 h-5 w-5" />
              Browse Channels
            </Button>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-foreground">Categories</h2>
          <Button variant="ghost" className="text-primary">
            View All
          </Button>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
          {categories.map((category) => (
            <Card key={category.id} className="group cursor-pointer hover:scale-105 transition-transform">
              <CardContent className="p-4 text-center space-y-3">
                <div className={`w-12 h-12 rounded-xl ${category.color} flex items-center justify-center text-2xl mx-auto group-hover:scale-110 transition-transform`}>
                  {category.icon}
                </div>
                <div>
                  <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                    {category.name}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {category.channels} channels
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Popular Channels */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-bold text-foreground">Popular Now</h2>
            <Badge variant="secondary" className="bg-live-indicator/20 text-live-indicator border-0">
              <TrendingUp className="w-3 h-3 mr-1" />
              Trending
            </Badge>
          </div>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {popularChannels.map((channel) => (
            <Card key={channel.id} className="group cursor-pointer overflow-hidden">
              <div className="relative aspect-video bg-muted">
                <img 
                  src={channel.thumbnail}
                  alt={channel.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="absolute bottom-2 right-2 flex items-center gap-1 text-white text-xs">
                    <span className="w-2 h-2 bg-live-indicator rounded-full animate-pulse"></span>
                    {channel.viewers}
                  </div>
                </div>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-12 h-12 bg-primary/90 rounded-full flex items-center justify-center">
                    <Play className="w-5 h-5 text-white ml-0.5" fill="currentColor" />
                  </div>
                </div>
              </div>
              <CardContent className="p-3">
                <h3 className="font-medium text-foreground truncate group-hover:text-primary transition-colors">
                  {channel.name}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {channel.category}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Recently Watched */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-bold text-foreground">Continue Watching</h2>
            <Clock className="w-5 h-5 text-muted-foreground" />
          </div>
          <Button variant="ghost" className="text-primary">
            View All
          </Button>
        </div>
        
        <Card className="p-6 text-center">
          <div className="space-y-3">
            <Clock className="w-12 h-12 text-muted-foreground mx-auto" />
            <h3 className="text-lg font-medium text-foreground">No Recent Activity</h3>
            <p className="text-muted-foreground">
              Start watching channels to see your recently viewed content here.
            </p>
            <Button className="mt-4">
              Browse Channels
            </Button>
          </div>
        </Card>
      </section>
    </div>
  );
};

export default Home;