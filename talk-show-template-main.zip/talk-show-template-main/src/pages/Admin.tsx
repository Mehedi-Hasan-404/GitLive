import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const Admin = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    document.title = "Admin Login | StreamHub";
    const canonical = document.querySelector('link[rel="canonical"]') || document.createElement("link");
    canonical.setAttribute("rel", "canonical");
    canonical.setAttribute("href", window.location.origin + "/admin");
    document.head.appendChild(canonical);
  }, []);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Placeholder: implement Supabase auth later
    // Navigate after successful login
    // navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sr-only">
        <h1>Admin Login - StreamHub</h1>
        <p>Secure access for StreamHub administrators.</p>
      </header>

      <main className="container max-w-screen-sm mx-auto px-4 py-16">
        <section aria-labelledby="admin-login" className="bg-card rounded-xl border border-border shadow-sm p-6">
          <h2 id="admin-login" className="text-2xl font-semibold text-foreground mb-1">Admin Login</h2>
          <p className="text-sm text-muted-foreground mb-6">Restricted access. Authorized personnel only.</p>

          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                autoComplete="username"
                placeholder="admin@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                placeholder="Your secure password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <Button type="submit" className="w-full">Sign in</Button>
          </form>
        </section>
      </main>
    </div>
  );
};

export default Admin;
