import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import ChannelSection from "@/components/ChannelSection";
import Footer from "@/components/Footer";

// Import channel images
import sports1 from "@/assets/sports-1.png";
import sports2 from "@/assets/sports-2.png";
import movie1 from "@/assets/movie-1.png";
import movie2 from "@/assets/movie-2.png";
import news1 from "@/assets/news-1.png";
import entertainment1 from "@/assets/entertainment-1.png";

const Index = () => {
  // Sample channel data
  const sportsChannels = [
    {
      id: "sports-1",
      name: "Premier Sports",
      category: "Football",
      viewers: "24.5K",
      isLive: true,
      isPremium: false,
      image: sports1,
      description: "Live football matches and highlights"
    },
    {
      id: "sports-2", 
      name: "Basketball Pro",
      category: "Basketball",
      viewers: "18.2K",
      isLive: true,
      isPremium: true,
      image: sports2,
      description: "NBA games and basketball content"
    },
    {
      id: "sports-3",
      name: "Sports Central",
      category: "Multi-Sport",
      viewers: "31.7K",
      isLive: true,
      isPremium: false,
      image: sports1,
      description: "All sports coverage 24/7"
    }
  ];

  const movieChannels = [
    {
      id: "movie-1",
      name: "Cinema Gold",
      category: "Movies",
      viewers: "45.1K",
      isLive: true,
      isPremium: false,
      image: movie1,
      description: "Classic and new movies"
    },
    {
      id: "movie-2",
      name: "Premium Films",
      category: "Premium",
      viewers: "28.9K",
      isLive: true,
      isPremium: true,
      image: movie2,
      description: "Latest blockbuster releases"
    }
  ];

  const entertainmentChannels = [
    {
      id: "entertainment-1",
      name: "Music Live",
      category: "Music",
      viewers: "67.3K",
      isLive: true,
      isPremium: false,
      image: entertainment1,
      description: "Live music and concerts"
    },
    {
      id: "news-1",
      name: "Global News",
      category: "News",
      viewers: "123.5K",
      isLive: true,
      isPremium: false,
      image: news1,
      description: "Breaking news and updates"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="space-y-16 pb-16">
        <HeroSection />
        
        <div className="container max-w-screen-2xl space-y-12">
          <ChannelSection 
            title="Sports Channels"
            channels={sportsChannels}
          />
          
          <ChannelSection 
            title="Movie Channels" 
            channels={movieChannels}
          />
          
          <ChannelSection 
            title="Entertainment & News"
            channels={entertainmentChannels}
          />
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
