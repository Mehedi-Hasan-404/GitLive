import { useEffect, useRef, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize, 
  Settings, 
  SkipBack, 
  SkipForward,
  ArrowLeft,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Card } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

// Import HLS.js and Shaka Player
import Hls from 'hls.js';
// import shaka from 'shaka-player';

const Player = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState([50]);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showControls, setShowControls] = useState(true);
  const [quality, setQuality] = useState('Auto');
  
  // Get stream parameters from URL
  const streamUrl = searchParams.get('url') || '';
  const streamName = searchParams.get('name') || 'Live Stream';
  const streamType = searchParams.get('type') || 'unknown';

  const controlsTimeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (!streamUrl) {
      toast({
        variant: "destructive",
        title: "No Stream URL",
        description: "Please provide a valid stream URL"
      });
      navigate('/');
      return;
    }

    // Initialize player based on stream type
    initializePlayer();
    
    return () => {
      // Cleanup
      if (videoRef.current) {
        videoRef.current.pause();
        videoRef.current.src = '';
      }
    };
  }, [streamUrl]);

  const initializePlayer = async () => {
    if (!videoRef.current) return;

    setIsLoading(true);
    setError(null);

    try {
      const video = videoRef.current;
      
      if (streamType === 'HLS' || streamUrl.includes('.m3u8') || streamUrl.includes('.m3u')) {
        // HLS Stream handling
        if (Hls.isSupported()) {
          // Use HLS.js for browsers that support it
          const hls = new Hls();
          hls.loadSource(streamUrl);
          hls.attachMedia(video);
          
          hls.on(Hls.Events.MANIFEST_PARSED, () => {
            toast({
              title: "HLS Stream Ready",
              description: "Stream loaded successfully"
            });
          });
          
          hls.on(Hls.Events.ERROR, (event, data) => {
            console.error('HLS Error:', data);
            if (data.fatal) {
              setError(`HLS Error: ${data.details}`);
            }
          });
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
          // Native HLS support (Safari)
          video.src = streamUrl;
          toast({
            title: "HLS Stream",
            description: "Loading HLS stream with native support..."
          });
        } else {
          setError("HLS streams are not supported in this browser");
        }
      } else if (streamType === 'DASH' || streamUrl.includes('.mpd')) {
        // DASH Stream with Shaka Player
        // await shaka.Player.probeSupport();
        // const player = new shaka.Player(video);
        // await player.load(streamUrl);
        
        // For demo purposes
        toast({
          title: "DASH Stream",
          description: "DASH streams require Shaka Player library"
        });
        setError("DASH streams not fully implemented in demo");
      } else {
        // Direct stream (MP4, etc.)
        video.src = streamUrl;
        toast({
          title: "Direct Stream",
          description: "Loading direct video stream..."
        });
      }
      
      setIsLoading(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load stream');
      setIsLoading(false);
      toast({
        variant: "destructive",
        title: "Stream Error",
        description: "Failed to load the stream"
      });
    }
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (value: number[]) => {
    if (!videoRef.current) return;
    
    const newVolume = value[0];
    setVolume([newVolume]);
    videoRef.current.volume = newVolume / 100;
    
    if (newVolume === 0) {
      setIsMuted(true);
    } else if (isMuted) {
      setIsMuted(false);
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const skip = (seconds: number) => {
    if (!videoRef.current) return;
    
    videoRef.current.currentTime += seconds;
  };

  const handleMouseMove = () => {
    setShowControls(true);
    
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    
    controlsTimeoutRef.current = setTimeout(() => {
      setShowControls(false);
    }, 3000);
  };

  const formatTime = (time: number) => {
    const hours = Math.floor(time / 3600);
    const minutes = Math.floor((time % 3600) / 60);
    const seconds = Math.floor(time % 60);
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div 
      className="fixed inset-0 bg-black z-50 flex flex-col"
      onMouseMove={handleMouseMove}
    >
      {/* Header */}
      <div className={`flex items-center justify-between p-4 bg-gradient-to-b from-black/80 to-transparent transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          <div>
            <h1 className="text-white font-semibold">{streamName}</h1>
            <p className="text-white/70 text-sm">{streamType} Stream</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20"
          >
            {quality}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
          >
            <Settings className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Video Container */}
      <div className="flex-1 relative flex items-center justify-center">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50">
            <Card className="p-6 bg-black/80 border-white/20">
              <div className="flex items-center gap-3 text-white">
                <Loader2 className="h-6 w-6 animate-spin" />
                <span>Loading stream...</span>
              </div>
            </Card>
          </div>
        )}
        
        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50">
            <Card className="p-6 bg-red-900/80 border-red-500/20 text-center">
              <div className="text-white space-y-2">
                <h3 className="font-semibold">Stream Error</h3>
                <p className="text-sm text-red-200">{error}</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={initializePlayer}
                  className="mt-4"
                >
                  Retry
                </Button>
              </div>
            </Card>
          </div>
        )}
        
        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          onClick={togglePlay}
          onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
          onDurationChange={(e) => setDuration(e.currentTarget.duration)}
          onProgress={(e) => {
            if (e.currentTarget.buffered.length > 0) {
              setBuffered(e.currentTarget.buffered.end(0));
            }
          }}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onError={(e) => setError('Video playback error')}
        />
      </div>

      {/* Controls */}
      <div className={`p-4 bg-gradient-to-t from-black/80 to-transparent transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        {/* Progress Bar */}
        <div className="mb-4">
          <Slider
            value={[currentTime]}
            max={duration || 100}
            step={1}
            onValueChange={(value) => {
              if (videoRef.current) {
                videoRef.current.currentTime = value[0];
              }
            }}
            className="w-full"
          />
          <div className="flex justify-between text-white/70 text-sm mt-1">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>
        
        {/* Control Buttons */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => skip(-10)}
              className="text-white hover:bg-white/20"
            >
              <SkipBack className="h-5 w-5" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={togglePlay}
              className="text-white hover:bg-white/20 w-12 h-12"
            >
              {isPlaying ? (
                <Pause className="h-6 w-6" fill="currentColor" />
              ) : (
                <Play className="h-6 w-6" fill="currentColor" />
              )}
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => skip(10)}
              className="text-white hover:bg-white/20"
            >
              <SkipForward className="h-5 w-5" />
            </Button>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Volume */}
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleMute}
                className="text-white hover:bg-white/20"
              >
                {isMuted || volume[0] === 0 ? (
                  <VolumeX className="h-5 w-5" />
                ) : (
                  <Volume2 className="h-5 w-5" />
                )}
              </Button>
              <Slider
                value={volume}
                max={100}
                step={1}
                onValueChange={handleVolumeChange}
                className="w-20"
              />
            </div>
            
            {/* Fullscreen */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleFullscreen}
              className="text-white hover:bg-white/20"
            >
              {isFullscreen ? (
                <Minimize className="h-5 w-5" />
              ) : (
                <Maximize className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Player;