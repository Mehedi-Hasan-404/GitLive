import { useState } from 'react';
import { Plus, Upload, Link, Trash2, Play, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

const MyPlaylists = () => {
  const [playlists, setPlaylists] = useState([
    {
      id: 1,
      name: 'IPTV Sports Package',
      url: 'https://example.com/sports.m3u8',
      channels: 45,
      format: 'M3U8',
      dateAdded: '2024-01-15'
    },
    {
      id: 2,
      name: 'Movie Channels HD',
      url: 'https://example.com/movies.m3u',
      channels: 28,
      format: 'M3U',
      dateAdded: '2024-01-10'
    }
  ]);
  
  const [playlistUrl, setPlaylistUrl] = useState('');
  const [playlistName, setPlaylistName] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  const { toast } = useToast();

  const handleAddPlaylistUrl = () => {
    if (!playlistUrl.trim()) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please enter a playlist URL"
      });
      return;
    }

    const newPlaylist = {
      id: Date.now(),
      name: playlistName || 'New Playlist',
      url: playlistUrl,
      channels: Math.floor(Math.random() * 100) + 10, // Mock channel count
      format: playlistUrl.includes('.m3u8') ? 'M3U8' : 'M3U',
      dateAdded: new Date().toISOString().split('T')[0]
    };

    setPlaylists([...playlists, newPlaylist]);
    setPlaylistUrl('');
    setPlaylistName('');
    setIsAddDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Playlist added successfully"
    });
  };

  const handleDeletePlaylist = (id: number) => {
    setPlaylists(playlists.filter(p => p.id !== id));
    toast({
      title: "Deleted",
      description: "Playlist removed"
    });
  };

  const handleLoadPlaylist = (playlist: any) => {
    toast({
      title: "Loading Playlist",
      description: `Loading ${playlist.name} with ${playlist.channels} channels`
    });
    // TODO: Navigate to playlist view or load channels
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">My Playlists</h1>
          <p className="text-muted-foreground">
            Manage your custom M3U/M3U8 playlists and JSON channel lists
          </p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Playlist
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Playlist</DialogTitle>
            </DialogHeader>
            <Tabs defaultValue="url" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="url">URL</TabsTrigger>
                <TabsTrigger value="file">File Upload</TabsTrigger>
              </TabsList>
              
              <TabsContent value="url" className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Playlist Name (Optional)</label>
                  <Input
                    placeholder="My IPTV Playlist"
                    value={playlistName}
                    onChange={(e) => setPlaylistName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Playlist URL</label>
                  <Input
                    placeholder="https://example.com/playlist.m3u8"
                    value={playlistUrl}
                    onChange={(e) => setPlaylistUrl(e.target.value)}
                  />
                </div>
                <Button onClick={handleAddPlaylistUrl} className="w-full">
                  <Link className="mr-2 h-4 w-4" />
                  Add from URL
                </Button>
              </TabsContent>
              
              <TabsContent value="file" className="space-y-4">
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                  <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-sm text-muted-foreground mb-2">
                    Drag and drop your M3U file here, or click to browse
                  </p>
                  <Button variant="outline" size="sm">
                    Choose File
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Supported formats: .m3u, .m3u8, .json
                </p>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      </div>

      {/* Supported Formats Info */}
      <Card className="bg-muted/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <FileText className="h-5 w-5 text-primary mt-0.5" />
            <div>
              <h3 className="font-medium text-foreground mb-2">Supported Formats</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-muted-foreground">
                <div>
                  <strong>M3U/M3U8:</strong> Standard IPTV playlist format with #EXTINF tags
                </div>
                <div>
                  <strong>JSON:</strong> Array of channel objects with name, url, logo properties
                </div>
                <div>
                  <strong>Extended:</strong> Support for #KODIPROP, #EXTVLCOPT, and DRM tags
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Playlists Grid */}
      {playlists.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {playlists.map((playlist) => (
            <Card key={playlist.id} className="group hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-lg truncate">{playlist.name}</CardTitle>
                    <p className="text-sm text-muted-foreground truncate mt-1">
                      {playlist.url}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDeletePlaylist(playlist.id)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      {playlist.format}
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      {playlist.channels} channels
                    </span>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {playlist.dateAdded}
                  </span>
                </div>
                
                <Button 
                  onClick={() => handleLoadPlaylist(playlist)}
                  className="w-full"
                  size="sm"
                >
                  <Play className="mr-2 h-4 w-4" />
                  Load Playlist
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="p-12 text-center">
          <div className="space-y-4">
            <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center">
              <FileText className="w-8 h-8 text-muted-foreground" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-semibold text-foreground">No Playlists Added</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                Add your first M3U or M3U8 playlist to get started. You can add playlists from URLs or upload local files.
              </p>
            </div>
            <Button onClick={() => setIsAddDialogOpen(true)} className="mt-4">
              <Plus className="mr-2 h-4 w-4" />
              Add Your First Playlist
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
};

export default MyPlaylists;