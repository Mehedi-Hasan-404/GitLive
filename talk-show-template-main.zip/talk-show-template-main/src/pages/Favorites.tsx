import { Heart, Grid3X3, List } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const Favorites = () => {
  // Mock favorites data - in real app this would come from localStorage/state
  const favorites = [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Favorites</h1>
          <p className="text-muted-foreground">
            Your saved channels and content
          </p>
        </div>
        
        {favorites.length > 0 && (
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Grid3X3 className="mr-2 h-4 w-4" />
              Grid View
            </Button>
            <Button variant="ghost" size="sm">
              <List className="mr-2 h-4 w-4" />
              List View
            </Button>
          </div>
        )}
      </div>

      {/* Content */}
      {favorites.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="space-y-4">
            <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center">
              <Heart className="w-8 h-8 text-muted-foreground" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-semibold text-foreground">No Favorites Yet</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                Start adding channels to your favorites by clicking the heart icon on any channel card. 
                Your favorite channels will appear here for quick access.
              </p>
            </div>
            <div className="flex gap-4 justify-center pt-4">
              <Button>
                Browse Live TV
              </Button>
              <Button variant="outline">
                Explore Categories
              </Button>
            </div>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {/* Favorite channel cards would go here */}
        </div>
      )}
    </div>
  );
};

export default Favorites;