import { useState } from 'react';
import { Filter, Grid3X3, List, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import ChannelCard from '@/components/ChannelCard';

// Import existing channel images
import sports1 from "@/assets/sports-1.png";
import sports2 from "@/assets/sports-2.png";
import movie1 from "@/assets/movie-1.png";
import movie2 from "@/assets/movie-2.png";
import news1 from "@/assets/news-1.png";
import entertainment1 from "@/assets/entertainment-1.png";

// Extended channel data for Live TV
const allChannels = [
  // Sports Channels
  { id: "sports-1", name: "Premier Sports", category: "Sports", viewers: "24.5K", isLive: true, isPremium: false, image: sports1, description: "Live football matches and highlights" },
  { id: "sports-2", name: "Basketball Pro", category: "Sports", viewers: "18.2K", isLive: true, isPremium: true, image: sports2, description: "NBA games and basketball content" },
  { id: "sports-3", name: "Sports Central", category: "Sports", viewers: "31.7K", isLive: true, isPremium: false, image: sports1, description: "All sports coverage 24/7" },
  
  // Movie Channels  
  { id: "movie-1", name: "Cinema Gold", category: "Movies", viewers: "45.1K", isLive: true, isPremium: false, image: movie1, description: "Classic and new movies" },
  { id: "movie-2", name: "Premium Films", category: "Movies", viewers: "28.9K", isLive: true, isPremium: true, image: movie2, description: "Latest blockbuster releases" },
  { id: "movie-3", name: "Action Movies", category: "Movies", viewers: "22.4K", isLive: true, isPremium: false, image: movie1, description: "Non-stop action entertainment" },
  
  // Entertainment & News
  { id: "entertainment-1", name: "Music Live", category: "Entertainment", viewers: "67.3K", isLive: true, isPremium: false, image: entertainment1, description: "Live music and concerts" },
  { id: "news-1", name: "Global News", category: "News", viewers: "123.5K", isLive: true, isPremium: false, image: news1, description: "Breaking news and updates" },
  { id: "entertainment-2", name: "Comedy Central", category: "Entertainment", viewers: "35.8K", isLive: true, isPremium: false, image: entertainment1, description: "Comedy shows and stand-up" },
  { id: "news-2", name: "Business News", category: "News", viewers: "89.2K", isLive: true, isPremium: true, image: news1, description: "Financial and market news" }
];

const categories = ['All', 'Sports', 'Movies', 'News', 'Entertainment'];

const LiveTV = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredChannels = allChannels.filter(channel => {
    const matchesCategory = selectedCategory === 'All' || channel.category === selectedCategory;
    const matchesSearch = channel.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         channel.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const liveChannelCount = filteredChannels.filter(c => c.isLive).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Live TV</h1>
          <p className="text-muted-foreground">
            {liveChannelCount} live channels available
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          {/* View Mode Toggle */}
          <div className="hidden sm:flex items-center bg-muted rounded-lg p-1">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('grid')}
              className="h-8 w-8 p-0"
            >
              <Grid3X3 className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('list')}
              className="h-8 w-8 p-0"
            >
              <List className="h-4 w-4" />
            </Button>
          </div>

          <Button variant="outline" size="sm" className="hidden md:flex">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search channels..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Category Filters */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {categories.map((category) => {
          const isSelected = selectedCategory === category;
          const categoryCount = category === 'All' 
            ? allChannels.length 
            : allChannels.filter(c => c.category === category).length;
          
          return (
            <Button
              key={category}
              variant={isSelected ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className="whitespace-nowrap"
            >
              {category}
              <Badge variant="secondary" className="ml-2 text-xs">
                {categoryCount}
              </Badge>
            </Button>
          );
        })}
      </div>

      {/* Channels Grid */}
      {filteredChannels.length > 0 ? (
        <div className={`
          ${viewMode === 'grid' 
            ? 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4' 
            : 'grid grid-cols-1 sm:grid-cols-2 gap-4'
          }
        `}>
          {filteredChannels.map((channel) => (
            <ChannelCard
              key={channel.id}
              name={channel.name}
              category={channel.category}
              viewers={channel.viewers}
              isLive={channel.isLive}
              isPremium={channel.isPremium}
              image={channel.image}
              description={channel.description}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-muted-foreground">
            No channels found matching your search criteria.
          </p>
        </div>
      )}
    </div>
  );
};

export default LiveTV;